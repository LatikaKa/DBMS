USE ECommerce;
-- QUEST 5) 	Display the Supplier details who can supply more than one product;
/* -- TABLE USED
SELECT * FROM supplier;
SELECT * FROM SUPPLIER_PRICING;
*/
--
-- SELECT SUPP_ID FROM supplier_pricing GROUP BY SUPP_ID HAVING COUNT(SUPP_ID)>1;
--

SELECT SP.SUPP_ID, SP.SUPP_NAME, SP.SUPP_CITY, SP.SUPP_PHONE FROM supplier AS SP
 INNER JOIN supplier_pricing AS SPR
 ON SP.SUPP_ID = SPR.SUPP_ID
 GROUP BY SP.SUPP_ID HAVING COUNT(SPR.SUPP_ID)>1;






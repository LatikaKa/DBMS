USE ECommerce;
-- QUEST 5) 	Display the Supplier details who can supply more than one product;
SELECT * FROM supplier;
SELECT * FROM PRODUCT;
SELECT * FROM SUPPLIER_PRICING;
--
SELECT * FROM supplier_pricing HAVING COUNT(SUPP_ID)>1;
--

SELECT S.SUPP_ID, SUPP_NAME,SUPP_CITY,SUPP_PHONE FROM supplier AS S
INNER JOIN
(SELECT * FROM supplier_pricing GROUP BY SUPP_ID HAVING COUNT(SUPP_ID)>1) AS SP
ON
S.SUPP_ID = SP.SUPP_ID;




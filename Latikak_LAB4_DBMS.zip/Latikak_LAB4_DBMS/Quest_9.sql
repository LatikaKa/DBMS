USE ECommerce;
-- Quest 9) Create a stored procedure to display supplier id, name, rating and Type_of_Service. For Type_of_Service, If rating =5, print “Excellent Service”,If rating >4 print “Good Service”, If rating >2 print “Average Service” else print “Poor Service”.
/*
-- TABLE USED;
SELECT * FROM SUPPLIER;
SELECT * FROM RATING;
SELECT * FROM SUPPLIER_PRICING;
SELECT * FROM OrderTbl;
*/
/*
CREATE STORED PROCEDURE
*/

DROP PROCEDURE IF EXISTS ShowSupplierRating;

 DELIMITER //
CREATE PROCEDURE ShowSupplierRating()
BEGIN
	SELECT TEMP.SUPP_ID, TEMP.SUPP_NAME, TEMP.AVERAGE,
	CASE WHEN TEMP.AVERAGE = 5 THEN
	'Excellent Service'
	WHEN TEMP.AVERAGE >4 THEN
	'Good Service'
	WHEN TEMP.AVERAGE > 2 THEN
	'Average Service'
	ELSE
	'Poor Service'
	END AS 'Type_Of_Service'
	  FROM (
				SELECT  S.SUPP_ID,S.SUPP_NAME,  
				-- SUM(RT.RAT_RATESTARS) AS 'SUM OF RATING',
				-- COUNT(RT.RAT_RATESTARS) AS 'COUNT OF RATING',
				SUM(RT.RAT_RATESTARS) / COUNT(RT.RAT_RATESTARS) AS 'AVERAGE'
				 FROM SUPPLIER AS S 
				INNER JOIN SUPPLIER_PRICING AS SP
				ON S.SUPP_ID = SP.SUPP_ID
				INNER JOIN OrderTbl AS OT
				ON SP.PRICING_ID = OT.PRICING_ID
				INNER JOIN RATING AS RT
				ON OT.ORD_ID = RT.ORD_ID
				 GROUP BY S.SUPP_ID,S.SUPP_NAME
			) AS TEMP
	  ORDER BY TEMP.SUPP_ID; 
END //

 DELIMITER ;

CALL ShowSupplierRating();
USE ECommerce;
-- QUEST 6)	Find the least expensive product from each category and print the table with category id, name, product name and price of the product.

SELECT * FROM CATEGORY;
SELECT * FROM PRODUCT;
SELECT * FROM SUPPLIER_PRICING;

---
SELECT CATEGORY.CAT_ID,category.CAT_NAME, TAB3.PRO_NAME, MIN(TAB3.MIN_PRICE) AS Min_Price FROM CATEGORY
INNER JOIN
	(
		 SELECT product.CAT_ID,product.PRO_NAME, TAB2.* FROM product
		 INNER JOIN
			(SELECT PRO_ID,MIN(SUPP_PRICE) AS MIN_PRICE FROM supplier_pricing GROUP BY PRO_ID) 
 			AS TAB2  WHERE TAB2.PRO_ID = product.PRO_ID
	) AS TAB3	WHERE TAB3.CAT_ID = CATEGORY.CAT_ID 
 
group by TAB3.CAT_ID;
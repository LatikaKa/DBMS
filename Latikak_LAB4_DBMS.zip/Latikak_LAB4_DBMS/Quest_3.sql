USE ECommerce;
-- QUEST 3)	Display the total number of customers based on gender who have placed orders of worth at least Rs.3000.
SELECT * FROM CUSTOMER C
INNER JOIN OrderTbl ORT
ON C.Cus_ID = ORT.CUS_ID
HAVING ORD_AMOUNT >= 3000
;
----
SELECT COUNT(tab2.CUS_GENDER) as No_Of_Customers, tab2.CUS_GENDER FROM 
 (
 	SELECT tab1.CUS_ID,tab1.CUS_NAME,tab1.CUS_GENDER,tab1.ORD_AMOUNT FROM
	(
		SELECT  orderTbl.*, customer.CUS_NAME,customer.CUS_GENDER   from orderTbl 
		INNER JOIN  customer WHERE  orderTbl.CUS_ID =customer.CUS_ID HAVING  orderTbl.ORD_AMOUNT>=3000
	) AS tab1 GROUP BY tab1.CUS_ID
 ) AS tab2 GROUP BY tab2.CUS_GENDER;

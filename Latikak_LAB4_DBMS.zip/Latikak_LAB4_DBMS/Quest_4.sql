create database ECommerce;
-- Quest 4) 	Display all the orders along with product name ordered by a customer having Customer_Id=2
SELECT * FROM ORDERTBL;
SELECT * FROM PRODUCT;
SELECT * FROM CUSTOEMR;
SELECT * FROM supplier_pricing;

----
SELECT distinct P.PRO_NAME, C.CUS_NAME, O.ORD_ID FROM PRODUCT AS P, CUSTOMER AS C,
supplier_pricing AS SP, 
ORDERTBL AS O
WHERE C.CUS_ID = 2
AND C.CUS_ID = O.CUS_ID
AND O.PRICING_ID = SP.PRICING_ID
AND P.PRO_ID = SP.PRO_ID
 ;


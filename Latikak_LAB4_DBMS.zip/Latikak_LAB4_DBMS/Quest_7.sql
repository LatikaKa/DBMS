USE ECommerce;
-- Quest 7)	Display the Id and Name of the Product ordered after “2021-10-05”.
SELECT * FROM ordertbl WHERE  ORD_DATE>'2021-10-05';
 SELECT * FROM supplier_pricing;
 SELECT * FROM product;
 
 --
 
 SELECT P.PRO_ID, P.PRO_NAME
 -- , OT.ORD_DATE 
 FROM OrderTbl AS OT
 INNER JOIN SUPPLIER_PRICING AS SP
 ON SP.PRICING_ID = OT.PRICING_ID
 INNER JOIN PRODUCT AS P
 ON P.PRO_ID = SP.PRO_ID
 WHERE ORD_DATE > '2021-10-05';
 